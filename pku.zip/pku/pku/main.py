#__author__ = 'cuihu1'

from scrapy import cmdline

cmdline.execute('scrapy crawl pkuspider')
